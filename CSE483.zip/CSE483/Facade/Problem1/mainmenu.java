public class mainmenu {
    public static void main(String[] args) {
        menuFacade menuFacade = new menuFacade();
        menuFacade.showFullMenu();
    }
}
