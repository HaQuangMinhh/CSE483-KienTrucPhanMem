public class veggie {
    public void showMenu() {
        System.out.println("Veggie Menu:");
        System.out.println("- Vegetable Stir Fry");
        System.out.println("- Pasta Primavera");
        System.out.println("- Garden Salad");
    }

}
