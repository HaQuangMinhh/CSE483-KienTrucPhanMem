public class nonveggie {
    public void showMenu() {
        System.out.println("Non-Veggie Menu:");
        System.out.println("- Grilled Chicken");
        System.out.println("- Beef Steak");
        System.out.println("- Fish Tacos");
    }

}
