/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.application;
/**
 *
 * @author Admin
 */
public class UserInterface {
     public void displayMenu() {
        System.out.println("1. Write Data");
        System.out.println("2. Compress Data");
        System.out.println("3. Encrypt Data");
        System.out.println("4. Exit");
    }
}
