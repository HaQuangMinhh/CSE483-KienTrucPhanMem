/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.applicationmain;

/**
 *
 * @author Admin
 */
public class ApplicationMain {

    public static void main(String[] args) {
         UserInterface ui = new UserInterface();
        ui.startApplication();
    }
}
