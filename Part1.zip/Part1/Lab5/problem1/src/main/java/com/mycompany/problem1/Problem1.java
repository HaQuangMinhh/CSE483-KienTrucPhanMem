/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.problem1;

import javax.swing.SwingUtilities;

/**
 *
 * @author Admin
 */
public class Problem1 {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LibraryUI().setVisible(true);
        });
    }
}
