public class observeA implements Subject {
public  void update(int, newstate)
[
    

]
}
