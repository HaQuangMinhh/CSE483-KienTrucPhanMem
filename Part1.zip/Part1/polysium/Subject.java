public class Subject {

}
