/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.problem1;

/**
 *
 * @author Admin
 */
public class Model {
 enum AccountType {
    SAVINGS, CHECKING, LOAN
}

  enum TransType {
    DEPOSIT, WITHDRAWAL
}

}
